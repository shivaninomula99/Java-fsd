package pack1;

public class proproaccessspecifiers {

		
		protected void display() 
	    { 
	        System.out.println("This is protected access specifier"); 
	    } 

}
